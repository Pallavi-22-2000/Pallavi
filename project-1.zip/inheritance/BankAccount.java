package inheritance;

public class BankAccount {
	public static void main(String[] args) {
		RegularCustomer regCust1 = new RegularCustomer("R123", "krishna", "Domestic", 10000);
		RegularCustomer regCust2 = new RegularCustomer("R345", "satish", "Business", 10000);
		
		EnterpriseCustomer entCust1 = new EnterpriseCustomer("E789", "madhu", "smallscale", 10000);
		EnterpriseCustomer entCust2 = new EnterpriseCustomer("E379", "lahari", "bigscale", 10000);
		
		//regular customer
		regCust1.showCustomerDetails();
		System.out.println("final amount: " + regCust1.get_final_amount(5,8));
		regCust2.showCustomerDetails();
		System.out.println("final amount: " + regCust2.get_final_amount(5,8));
		//Enterprise customer
		entCust1.showCustomerDetails();
		System.out.println("final amount: " + entCust1.get_final_amount(5,8));
		entCust2.showCustomerDetails();
		System.out.println("final amount: " + entCust2.get_final_amount(5,8));
		
	}

}
