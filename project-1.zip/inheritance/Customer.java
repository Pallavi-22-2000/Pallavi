
package inheritance;

public abstract class Customer {
	String customerId;
	String customerName;
	String customerType;
	
	Customer(String custId, String custName, String custType){
		this.customerId = custId;
		this.customerName = custName;
		this.customerType = custType;
	}
	
	void showCustomerDetails() {
		System.out.println("customer ID: " + this.customerId);
		System.out.println("customer Name: " + this.customerName);
		System.out.println("customer Type: " + this.customerType);
	}
	
	abstract double get_final_amount(double interest, int year);
	

}
